//
//  DayOfTravelProtocol.swift
//  DayOfTravel
//
//  Created by Dileep Vasa on 10/02/19.
//  Copyright © 2019 Dileep Vasa All rights reserved.
//

import UIKit

protocol DayOfTravelPresenterViewProtocol {
    
    var presenter : DayOfTravelPresenterProtocol? {get set}
    
    func getTravelsInfoResponse(travelInfo : TravelBean)
    func getTravelsInfoFrailed(message : String)
}

protocol DayOfTravelPresenterProtocol {
    
    var view : DayOfTravelPresenterViewProtocol? {get set}
    var interactor : DayOfTravelInteractorProtocol? {get set}
    var travelsInfo : [Travels]? {get set}
    
    func getTravelsInfo(airportCode : String)

}

protocol DayOfTravelRouterProtocol {
    
}

protocol DayOfTravelInteractorProtocol {
    
    var presenter  : DayOfTravelInteractorToPresenterPRotocol? {get set}
    func getTravelsInfoService(airportCode : String)
}

protocol DayOfTravelInteractorToPresenterPRotocol {
    
    func getTravelsInfoResponse(travelInfo : TravelBean?)
    func getTravelsInfoFrailed(message : String)

}
