//
//  DayOfTravelVCEntity.swift
//  DayOfTravel
//
//  Created by Dileep Vasa on 10/02/19.
//  Copyright © 2019 Dileep Vasa All rights reserved.
//

//   let travelBean = try TravelBean(json)
//
// To read values from URLs:
//
//   let task = URLSession.shared.travelBeanTask(with: url) { travelBean, response, error in
//     if let travelBean = travelBean {
//       ...
//     }
//   }
//   task.resume()

import Foundation

typealias TravelBean = [TravelBeanElement]

struct TravelBeanElement: Codable {
    let fltID: String?
    let carrier: Carrier?
    let orig, dest, cutOffTime: String?
    let fltDirection: Int?
    let schedDepTime, estDepTime, schedArrTime, estArrTime: String?
    let actualTime, origZuluOffset, destZuluOffset, destGate: String?
    let origGate: String?
    let codeShares: [CodeShare]?
    let tailID, fleetType: String?
    let status: Status?
    
    enum CodingKeys: String, CodingKey {
        case fltID = "FltId"
        case carrier = "Carrier"
        case orig = "Orig"
        case dest = "Dest"
        case cutOffTime = "CutOffTime"
        case fltDirection = "FltDirection"
        case schedDepTime = "SchedDepTime"
        case estDepTime = "EstDepTime"
        case schedArrTime = "SchedArrTime"
        case estArrTime = "EstArrTime"
        case actualTime = "ActualTime"
        case origZuluOffset = "OrigZuluOffset"
        case destZuluOffset = "DestZuluOffset"
        case destGate = "DestGate"
        case origGate = "OrigGate"
        case codeShares = "CodeShares"
        case tailID = "TailId"
        case fleetType = "FleetType"
        case status = "Status"
    }
}

enum Carrier: String, Codable {
    case carrierAS = "AS"
    case oo = "OO"
    case qx = "QX"
}

struct CodeShare: Codable {
    let fltID, carrier: String?
    
    enum CodingKeys: String, CodingKey {
        case fltID = "FltId"
        case carrier = "Carrier"
    }
}

enum Status: String, Codable {
    case empty = ""
    case onTime = "ON TIME"
}

// MARK: Convenience initializers and mutators

extension TravelBeanElement {
    init(data: Data) throws {
        self = try newJSONDecoder().decode(TravelBeanElement.self, from: data)
    }
    
    init(_ json: String, using encoding: String.Encoding = .utf8) throws {
        guard let data = json.data(using: encoding) else {
            throw NSError(domain: "JSONDecoding", code: 0, userInfo: nil)
        }
        try self.init(data: data)
    }
    
    init(fromURL url: URL) throws {
        try self.init(data: try Data(contentsOf: url))
    }
    
    func with(
        fltID: String?? = nil,
        carrier: Carrier?? = nil,
        orig: String?? = nil,
        dest: String?? = nil,
        cutOffTime: String?? = nil,
        fltDirection: Int?? = nil,
        schedDepTime: String?? = nil,
        estDepTime: String?? = nil,
        schedArrTime: String?? = nil,
        estArrTime: String?? = nil,
        actualTime: String?? = nil,
        origZuluOffset: String?? = nil,
        destZuluOffset: String?? = nil,
        destGate: String?? = nil,
        origGate: String?? = nil,
        codeShares: [CodeShare]?? = nil,
        tailID: String?? = nil,
        fleetType: String?? = nil,
        status: Status?? = nil
        ) -> TravelBeanElement {
        return TravelBeanElement(
            fltID: fltID ?? self.fltID,
            carrier: carrier ?? self.carrier,
            orig: orig ?? self.orig,
            dest: dest ?? self.dest,
            cutOffTime: cutOffTime ?? self.cutOffTime,
            fltDirection: fltDirection ?? self.fltDirection,
            schedDepTime: schedDepTime ?? self.schedDepTime,
            estDepTime: estDepTime ?? self.estDepTime,
            schedArrTime: schedArrTime ?? self.schedArrTime,
            estArrTime: estArrTime ?? self.estArrTime,
            actualTime: actualTime ?? self.actualTime,
            origZuluOffset: origZuluOffset ?? self.origZuluOffset,
            destZuluOffset: destZuluOffset ?? self.destZuluOffset,
            destGate: destGate ?? self.destGate,
            origGate: origGate ?? self.origGate,
            codeShares: codeShares ?? self.codeShares,
            tailID: tailID ?? self.tailID,
            fleetType: fleetType ?? self.fleetType,
            status: status ?? self.status
        )
    }
    
    func jsonData() throws -> Data {
        return try newJSONEncoder().encode(self)
    }
    
    func jsonString(encoding: String.Encoding = .utf8) throws -> String? {
        return String(data: try self.jsonData(), encoding: encoding)
    }
}

extension CodeShare {
    init(data: Data) throws {
        self = try newJSONDecoder().decode(CodeShare.self, from: data)
    }
    
    init(_ json: String, using encoding: String.Encoding = .utf8) throws {
        guard let data = json.data(using: encoding) else {
            throw NSError(domain: "JSONDecoding", code: 0, userInfo: nil)
        }
        try self.init(data: data)
    }
    
    init(fromURL url: URL) throws {
        try self.init(data: try Data(contentsOf: url))
    }
    
    func with(
        fltID: String?? = nil,
        carrier: String?? = nil
        ) -> CodeShare {
        return CodeShare(
            fltID: fltID ?? self.fltID,
            carrier: carrier ?? self.carrier
        )
    }
    
    func jsonData() throws -> Data {
        return try newJSONEncoder().encode(self)
    }
    
    func jsonString(encoding: String.Encoding = .utf8) throws -> String? {
        return String(data: try self.jsonData(), encoding: encoding)
    }
}

extension Array where Element == TravelBean.Element {
    init(data: Data) throws {
        self = try newJSONDecoder().decode(TravelBean.self, from: data)
    }
    
    init(_ json: String, using encoding: String.Encoding = .utf8) throws {
        guard let data = json.data(using: encoding) else {
            throw NSError(domain: "JSONDecoding", code: 0, userInfo: nil)
        }
        try self.init(data: data)
    }
    
    init(fromURL url: URL) throws {
        try self.init(data: try Data(contentsOf: url))
    }
    
    func jsonData() throws -> Data {
        return try newJSONEncoder().encode(self)
    }
    
    func jsonString(encoding: String.Encoding = .utf8) throws -> String? {
        return String(data: try self.jsonData(), encoding: encoding)
    }
}

fileprivate func newJSONDecoder() -> JSONDecoder {
    let decoder = JSONDecoder()
    if #available(iOS 10.0, OSX 10.12, tvOS 10.0, watchOS 3.0, *) {
        decoder.dateDecodingStrategy = .iso8601
    }
    return decoder
}

fileprivate func newJSONEncoder() -> JSONEncoder {
    let encoder = JSONEncoder()
    if #available(iOS 10.0, OSX 10.12, tvOS 10.0, watchOS 3.0, *) {
        encoder.dateEncodingStrategy = .iso8601
    }
    return encoder
}

// MARK: - URLSession response handlers

extension URLSession {
    fileprivate func codableTask<T: Codable>(with url: URL, completionHandler: @escaping (T?, URLResponse?, Error?) -> Void) -> URLSessionDataTask {
        return self.dataTask(with: url) { data, response, error in
            guard let data = data, error == nil else {
                completionHandler(nil, response, error)
                return
            }
            completionHandler(try? newJSONDecoder().decode(T.self, from: data), response, nil)
        }
    }
    
    func travelBeanTask(with url: URL, completionHandler: @escaping (TravelBean?, URLResponse?, Error?) -> Void) -> URLSessionDataTask {
        return self.codableTask(with: url, completionHandler: completionHandler)
    }
}
