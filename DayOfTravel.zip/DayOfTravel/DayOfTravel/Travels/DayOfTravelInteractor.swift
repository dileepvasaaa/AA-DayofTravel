//
//  DayOfTravelInteractor.swift
//  DayOfTravel
//
//  Created by Dileep Vasa on 10/02/19.
//  Copyright © 2019 Dileep Vasa All rights reserved.
//

import UIKit

class DayOfTravelInteractor: DayOfTravelInteractorProtocol {
    var presenter  : DayOfTravelInteractorToPresenterPRotocol?

    func getTravelsInfoService(airportCode : String) {
        
        let requestObject : TravelRequest = TravelRequest(airportCode: airportCode)
        NetworkManager().send(r: requestObject) { (success, response, error) in
            if success {
                self.presenter?.getTravelsInfoResponse(travelInfo: response?.travelsInfo)
            } else {
                self.presenter?.getTravelsInfoFrailed(message: "Fail to get Travels info!")
            }
        }
    }
}
