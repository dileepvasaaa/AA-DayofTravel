//
//  DayOfTravelRouter.swift
//  DayOfTravel
//
//  Created by Dileep Vasa on 10/02/19.
//  Copyright © 2019 Dileep Vasa All rights reserved.
//

import UIKit

class DayOfTravelRouter: DayOfTravelRouterProtocol {

    class func getDayOfTravelViewController() -> DayOfTravelVC {
        
        let dayOfView = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "DayOfTravelVC") as! DayOfTravelVC
        
        var presenter : DayOfTravelPresenterProtocol & DayOfTravelInteractorToPresenterPRotocol = DayOfTravelPresenter()
        var interactor : DayOfTravelInteractorProtocol = DayOfTravelInteractor()
        
        dayOfView.presenter = presenter
        presenter.view = dayOfView
        presenter.interactor = interactor
        interactor.presenter = presenter
        
        return dayOfView
    }
}

