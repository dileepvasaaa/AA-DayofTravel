//
//  DayOfTravelPresenter.swift
//  DayOfTravel
//
//  Created by Dileep Vasa on 10/02/19.
//  Copyright © 2019 Dileep Vasa All rights reserved.
//

import UIKit

class DayOfTravelPresenter: DayOfTravelPresenterProtocol {

    var view : DayOfTravelPresenterViewProtocol?
    var interactor : DayOfTravelInteractorProtocol?
    var travelsInfo : [Travels]?

    func getTravelsInfo(airportCode : String) {
        interactor?.getTravelsInfoService(airportCode: airportCode)
    }
}


extension DayOfTravelPresenter : DayOfTravelInteractorToPresenterPRotocol {
    
    func getTravelsInfoResponse(travelInfo: TravelBean?) {
        CoreDataManager.deleteEntityInfoFromCoreData(entityName: EntityNames.travels)
        if let info = travelInfo {
            for obj in info {
                CoreDataManager.saveTravelsInfoToTravelEntity(travelsInfo: obj)
            }
            self.travelsInfo = CoreDataManager.fetchDetails(entityName: EntityNames.travels) as? [Travels]
            
            self.view?.getTravelsInfoResponse(travelInfo: info)
        } else {
            self.view?.getTravelsInfoFrailed(message: "Message")
        }
    }
    
    func getTravelsInfoFrailed(message: String) {
        self.view?.getTravelsInfoFrailed(message: message)
    }
    
}
