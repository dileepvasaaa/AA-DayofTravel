//
//  DayOfTravelVC.swift
//  DayOfTravel
//
//  Created by Dileep Vasa on 10/02/19.
//  Copyright © 2019 Dileep Vasa All rights reserved.
//

import UIKit

class DayOfTravelVC: UIViewController {

    @IBOutlet weak var airportCodeTxt: UITextField!
    @IBOutlet weak var showBtn: UIButton!
    @IBOutlet weak var infoTableView: UITableView!
    
    var presenter : DayOfTravelPresenterProtocol?

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        infoTableView.tableFooterView = UIView()
        AppData.shared().getLastSearch()
        let lastSearch = AppData.shared().lastSearch
        airportCodeTxt.text = lastSearch
        
        self.presenter?.travelsInfo = CoreDataManager.fetchDetails(entityName: EntityNames.travels) as? [Travels]
        
        AppData.shared().getLastUpdatedTime()
        let time = AppData.shared().lastUpdatedTimeInterval
        let currentTime = Date().timeIntervalSince1970
        
        if let lastTime  = time , (lastTime * 600) < Int64(currentTime) {
            CoreDataManager.deleteEntityInfoFromCoreData(entityName: EntityNames.travels)
            self.presenter?.travelsInfo?.removeAll()
            
        }
        infoTableView.reloadData()

    }
    
    @IBAction func showTravelInfoAction(_ sender: Any) {
        if (airportCodeTxt.text?.count ?? 0) < 3 {
            print("Please enter valid Airport code!")
        } else {
            presenter?.getTravelsInfo(airportCode: airportCodeTxt.text?.uppercased() ?? "")
            AppData.shared().lastSearch = airportCodeTxt.text?.uppercased() ?? ""
        }
    }
}


extension DayOfTravelVC: DayOfTravelPresenterViewProtocol {
    
    func getTravelsInfoResponse(travelInfo: TravelBean) {
        AppData.shared().lastUpdatedTimeInterval = Int64(Date().timeIntervalSince1970)
        infoTableView.reloadData()
    }
    
    func getTravelsInfoFrailed(message: String) {
        print(message)
    }
    
    
}


extension DayOfTravelVC : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.presenter?.travelsInfo?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell : FlightInfoCell = tableView.dequeueReusableCell(withIdentifier: "infoCell", for: indexPath) as! FlightInfoCell
        let flightBean = self.presenter?.travelsInfo?[indexPath.row]
        cell.configureCell(flightBean: flightBean!)
        return cell
    }
    
    
}
