//
//  FlightInfoCell.swift
//  DayOfTravel
//
//  Created by Dileep Vasa on 10/02/19.
//  Copyright © 2019 Dileep Vasa All rights reserved.
//

import UIKit

class FlightInfoCell: UITableViewCell {

    @IBOutlet weak var fltImage: UIImageView!
    @IBOutlet weak var flightNumberLbl: UILabel!
    @IBOutlet weak var airportCodeLbl: UILabel!
    @IBOutlet weak var arrivalTime: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    func configureCell(flightBean : Travels) {
        self.fltImage.image = UIImage(named: "trip")
        self.flightNumberLbl.text = flightBean.flightNumber ?? ""
        self.airportCodeLbl.text = flightBean.airportCode ?? ""
        self.arrivalTime.text = flightBean.localTime ?? ""
        
    }
}
