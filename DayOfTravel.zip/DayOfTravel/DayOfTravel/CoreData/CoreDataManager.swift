//
//  CoreDataManager.swift
//  DayOfTravel
//
//  Created by Dileep Vasa on 11/02/19.
//  Copyright © 2019 Dileep Vasa All rights reserved.
//

import UIKit
import CoreData

struct EntityNames {
    static let travels = "Travels"
}

class CoreDataManager: NSObject {
    
    static let coreDataInstance = CoreDataManager()
    class func getContext() -> NSManagedObjectContext{
        return appDelegate.persistentContainer.viewContext
    }
    
    class func saveTravelsInfoToTravelEntity(travelsInfo : TravelBeanElement) {

        // Insert new message
        let context = CoreDataManager.getContext()
        
        let entity  = NSEntityDescription.entity(forEntityName: EntityNames.travels, in: context)
        let Object = NSManagedObject(entity: entity!, insertInto: context) as! Travels

        Object.flightNumber = travelsInfo.fltID ?? ""
        Object.airportCode = travelsInfo.orig ?? ""
        Object.localTime = travelsInfo.estArrTime ?? ""

        
        do {
            try context.save()
            print("saved!")
//            completion(true)
        } catch  {
            
            print(error.localizedDescription)
        }

    }
    
    class func  fetchDetails(entityName : String)->Array<Any>{
        
        var fetchResultsArray = Array<Any>()
        // Initialize Fetch Request
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>()
        // Create Entity Description
        let entityDescription = NSEntityDescription.entity(forEntityName: entityName, in: getContext())
        // Configure Fetch Request
        fetchRequest.entity = entityDescription
        do {
            let result = try getContext().fetch(fetchRequest)
            //            print(result)
            for item in result {
                fetchResultsArray.append(item)
            }
        } catch {
            let fetchError = error as NSError
            print(fetchError)
        }
        return fetchResultsArray
    }
    
    class func deleteEntityInfoFromCoreData(entityName : String) {
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: entityName)
        let result = try? getContext().fetch(fetchRequest)
        
        for object in result! {
            getContext().delete(object as! NSManagedObject)
        }
        do {
            try getContext().save()
            print("Delete Sucessfully!")
        } catch let error as NSError  {
            print("Could not save \(error), \(error.userInfo)")
        } catch {
            
        }
    }
    
    class func clearCoreData(entityName : String) {
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: entityName)
        let  deleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest)
        do {
            try getContext().execute(deleteRequest)
            print("deleted")
        } catch  {
            
            print(error.localizedDescription)
        }
        
    }
    
}

