//
//  AppData.swift
//  DayOfTravel
//
//  Created by Dileep Vasa on 10/02/19.
//  Copyright © 2019 Dileep Vasa All rights reserved.
//

import UIKit
import Foundation

var appDelegate:AppDelegate {
    return UIApplication.shared.delegate as! AppDelegate
}


class AppData: NSObject {

    fileprivate static var instance : AppData!
    
    // Singleton class creation.
    static func shared() -> AppData{
        if(nil == instance){
            instance = AppData()
        }
        return instance
    }

    var travelsList : TravelBean? = TravelBean.init() {
        didSet {
            UserDefaults.standard.removeObject(forKey: "TravelsInfoDefault")
            if let info = travelsList {
                UserDefaults.standard.set(info, forKey: "TravelsInfoDefault")
            }
        }
    }
    var lastSearch : String? = "" {
        didSet {
            UserDefaults.standard.removeObject(forKey: "LastSearch")
            UserDefaults.standard.set((lastSearch ?? ""), forKey: "LastSearch")
        }
    }
    
    var lastUpdatedTimeInterval : Int64? = nil {
        didSet {
            UserDefaults.standard.removeObject(forKey: "LastUpdatedTime")
            if let time = lastUpdatedTimeInterval {
                UserDefaults.standard.set(time, forKey: "LastUpdatedTime")
            }
        }
    }
    
    func getLastSearch()  {
        lastSearch = UserDefaults.standard.value(forKey: "LastSearch") as? String
    }
    
    func getTravelsInfo() {
        travelsList = UserDefaults.standard.value(forKey: "TravelsInfoDefault") as? TravelBean
    }
    
    func getLastUpdatedTime() {
        lastUpdatedTimeInterval = UserDefaults.standard.value(forKey: "LastUpdatedTime") as? Int64
    }
}

