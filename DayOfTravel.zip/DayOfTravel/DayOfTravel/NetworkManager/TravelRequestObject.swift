//
//  TravelRequestObject.swift
//  DayOfTravel
//
//  Created by Dileep Vasa on 10/02/19.
//  Copyright © 2019 Dileep Vasa All rights reserved.
//

import UIKit

struct TravelRequest : RequestObject {
    
    typealias response = TravelResponse

    var host: String
    var url: URL
    var method: String = "GET"
    var header: [[String : Any]]?
    var body: [String : Any]?
    
    func getHeaderJSON() -> [[String: Any]]? {
        var params = [String:Any]()
        params["Ocp-Apim-Subscription-Key"] = "0a570f0bf03d46089b7829d7304831e4"
        return [params]
        
    }
    init(airportCode : String) {
        host = "https://api.qa.alaskaair.net/aag/1/dayoftravel/airports/\(airportCode)/flights/flightInfo?minutesBefore=10&minutesAfter=120"
        url = URL(string: host)!
        header = getHeaderJSON()
        body = nil
    }
    
}

struct TravelResponse : DecodableResponse {
    var error : String?
    var travelsInfo : TravelBean?
    static func parse(data: Data, success: Bool) -> TravelResponse? {
        var response : TravelResponse = TravelResponse()
        if success {
            response.travelsInfo = try! TravelBean.init(data: data)
        } else {
            response.error = "Fail to get the travels info."
        }
        return response
    }
    
    
}
