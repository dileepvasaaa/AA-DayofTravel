//
//  NetworkManager.swift
//  DayOfTravel
//
//  Created by Dileep Vasa on 10/02/19.
//  Copyright © 2019 Dileep Vasa All rights reserved.
//
import Foundation
import Security
import SystemConfiguration

protocol RequestObject {
    var host: String{get}
    //    var path: String{get}
    var url: URL{get}
    var method: String{get}
    var header: [[String: Any]]? {get}
    var body: [String: Any]? {get}
    
    associatedtype response: DecodableResponse
}

protocol DecodableResponse {
    static func parse(data: Data, success: Bool) -> Self?
}

typealias Completion<T: RequestObject> = (_ success: Bool,_ response: T.response?,_ error: Error?) -> Void

class NetworkManager: NSObject {
    
    //MARK: Singleton Instance
    static let sharedInstance = NetworkManager()
    
    fileprivate var serverError: String = "Cannot establish connection with the Application and Server. Please try later."
    
    //MARK:- URL Request/Response
    func    send<T:RequestObject>(r:T,completion:@escaping Completion<T>) {
        let url = r.url
        var request = URLRequest(url: url)
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpMethod = r.method
        request.timeoutInterval = 10
        if r.header != nil{
            for header in r.header! {
                let key = header.keys.first
                request.setValue(header[key!] as? String, forHTTPHeaderField: key!)
            }
        }
        if r.body != nil {
            let bodyData = try! JSONSerialization.data(withJSONObject: r.body!, options: .prettyPrinted)
            var bodyStr = String(data: bodyData, encoding: .utf8)
            bodyStr = bodyStr?.replacingOccurrences(of: "\\", with: "")
            request.httpBody = bodyStr!.data(using: .utf8)!
            print("Request Body : \(bodyStr!)")
            print("Request URL : \(url)")
        }
        let config = URLSessionConfiguration.default
        let session = URLSession.init(configuration: config, delegate: nil, delegateQueue: OperationQueue.main)
        let task = session.dataTask(with: request) { (data, response, error) in
            //            print((response as! HTTPURLResponse).statusCode )
            //            print("URL:\(request.url) --- \((response as! HTTPURLResponse).statusCode)")
            guard error == nil else {
                completion(false, nil, nil)
                return
            }
            guard response is HTTPURLResponse else{
                completion(false, nil, nil)
                return
            }
            guard data != nil else {
                completion(false, nil, nil)
                return
            }
            guard (response as! HTTPURLResponse).statusCode == 200 else {
                let res = T.response.parse(data: data!, success: false)
                completion(false, res, nil)
                return
            }
            let res = T.response.parse(data: data!, success: true)
            guard res != nil else {
                completion(false, nil, nil)
                return
            }
            completion(true, res, nil)
        }
        task.resume()
    }
}
